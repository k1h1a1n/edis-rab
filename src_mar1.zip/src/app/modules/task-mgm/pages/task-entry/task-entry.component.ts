import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-task-entry',
  templateUrl: './task-entry.component.html',
  styleUrls: ['./task-entry.component.scss']
})
export class TaskEntryComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
